@extends('layouts.app')

@section('content')

<div class="clear"></div>
<!--end header -->
<!-- start all contant -->
<div class="con">
   <!-- start about me -->
   <section class="about">
       <div class="container">
         <h1>About Us</h1>
       </div>
   </section>
   <!-- end about me -->
   <!--start the two slide contant -->
<section class="slide">
   <div class="container">


       <div class="con2">
               <!-- start slide 1 -->
               <div class="secDiv1">
                   <div class="image">
                    <img class="rounded-circle" alt="avatar1" src="http://127.0.0.1:8000/user/main-img/Main_IMG.png" />
                </div>
                   <div class="inf">
                  <div class="row" id="customrow">
                  
                    <div class="col-md-12 text-center">
                        <h1>test</h1>
                    </div>
                    <div class="col-md-12 text-center">
                        <h1>test2</h1>
                    </div>
                    <div class="col-md-12 text-center">
                        <h1>test3</h1>
                    </div>
                  </div>
                  
                   </div>
               </div>
             <!-- end slide 1 -->
             <!-- start img for slide 1-->
               <div class="imageS1">
            </div>
             <!-- end img for slide 1-->
           <div class="secDiv2">
                  <h2>About Us</h2>
                  <div class="divv">We Can You Health</div>
                  <p>Lorem ipsum dolor sit amet، consetetur sadipscing elitr، sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam er، and Diam volutus at vero eos et accusam et justo du dolores et ea rebum. Stet clita kasd gubergren، no ne takimata sanctus est، Lorem ipsum dolor sit amet.</p>
                   <p>Lorem ipsum dolor all amet، consetetur sadipscing elitr، sed Diam nonumy eirmod tempor Invidunt ut Labore et dolore magna aliquyam erat، sed Diam voluptua.  vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren، no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>
                  <p>Lorem ipsum dolor at amet، consetetur sadipscing elit، sal Diam nonumy timod tempor Invidunt ut labore et dolore magna aliquyam crat، sed Diam voluptua.  vero eos et accusam et justo duo dolor et ea rebum. Stet clita kasd gubergren، no sea takimata st أ. Lorem ipsum dolor sit amet، consetetur sadipscing elitr، sed Diam nonumy eirmod tempor Invidunt ut Labore et dolore magna aliquam erat، sed Diam voluptua. في vero eos et accusam et justo duo dolores et ea rebum. gubergren، no sea takimata sanctus est Lorem ipsum dolor sit amet La pum dolor sit amet، conseteturcing eltir، sed Diam nonummy mod tempor invidunt ut labore et dolore magna aliquyam</p>
               
               <div class="inf2">
                   <div>
                        50.656
                        <span>Buskets</span>
                   </div>
                     
                   <div>
                        35%
                        <span>Cheaper</span>
                   </div>
                     
                   <div>
                        26.492
                        <span>People</span>
                   </div>
               </div>
           </div>
       
       </div>
   </div>
</section>


@endsection

