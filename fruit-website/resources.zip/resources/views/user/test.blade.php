@include('layouts.app')
@section('content')

<!DOCTYPE html>

    <!DOCTYPE html>
    <html lang="en">
        <head>
            <meta charset="UTF-8" />
            <title>froutt</title>
        </head>
        <body>
        <!-- start header -->
       
         <div class="clear"></div>
         <!--end header -->
         <!-- start all contant -->
         <div class="con">
            <!-- start about me -->
            <section class="about">
                <div class="container">
                  <img src="img/4.png" alt="flow">
                  <h1>About Us</h1>
                </div>
            </section>
            <!-- end about me -->
            <!--start the two slide contant -->
        <section class="slide">
            <div class="container">
                <div class="con2">
                        <!-- start slide 1 -->
                        <div class="secDiv1">
                            <div class="image">
                               <img src="img/5.jfif" alt="img">
                            </div>
                            <div class="inf">
                                <h2>Mohammad Abaallah</h2>
                                <span>CEO</span>
                                <h3>28 Years</h3>
                            </div>
                        </div>
                      <!-- end slide 1 -->
                      <!-- start img for slide 1-->
                        <div class="imageS1">
                               <img src="img/7.png" alt="img">
                        </div>
                      <!-- end img for slide 1-->
                    <div class="secDiv2">
                           <h2>About Us</h2>
                           <div class="divv">We Can You Health</div>
                           <p>Lorem ipsum dolor sit amet، consetetur sadipscing elitr، sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam er، and Diam volutus at vero eos et accusam et justo du dolores et ea rebum. Stet clita kasd gubergren، no ne takimata sanctus est، Lorem ipsum dolor sit amet.</p>
                            <p>Lorem ipsum dolor all amet، consetetur sadipscing elitr، sed Diam nonumy eirmod tempor Invidunt ut Labore et dolore magna aliquyam erat، sed Diam voluptua.  vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren، no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>
                           <p>Lorem ipsum dolor at amet، consetetur sadipscing elit، sal Diam nonumy timod tempor Invidunt ut labore et dolore magna aliquyam crat، sed Diam voluptua.  vero eos et accusam et justo duo dolor et ea rebum. Stet clita kasd gubergren، no sea takimata st أ. Lorem ipsum dolor sit amet، consetetur sadipscing elitr، sed Diam nonumy eirmod tempor Invidunt ut Labore et dolore magna aliquam erat، sed Diam voluptua. في vero eos et accusam et justo duo dolores et ea rebum. gubergren، no sea takimata sanctus est Lorem ipsum dolor sit amet La pum dolor sit amet، conseteturcing eltir، sed Diam nonummy mod tempor invidunt ut labore et dolore magna aliquyam</p>
                        
                        <div class="inf2">
                            <div>
                                 50.656
                                 <span>Buskets</span>
                            </div>
                              
                            <div>
                                 35%
                                 <span>Cheaper</span>
                            </div>
                              
                            <div>
                                 26.492
                                 <span>People</span>
                            </div>
                        </div>
                    </div>
                
                </div>
            </div>
        </section>
         
        </body>
    </html>
  
@endsection