@extends('layouts.app')

@section('content')

<div class="container-fluid mt-5" id="ContainerSection">
<div class="row d-flex     justify-content-center" id="customediv">

  <div class="col-md-3 m-5 containerCategory">
    <a class="containerCategory" href="{{ route('product', ['id' => "2"]) }}">

    <div class="d-flex justify-content-end flex-column">

      <img class="img-fluid custom-width mx-auto image-top-center" src="http://127.0.0.1:8000/user/main-img/Main_IMG.png" alt="">
     <div class="CustomTextCard">
      <h2 class="text-center">Title</h2>
      <p class="text-justify customP text-center text-truncate">
        Diem certam indicere. Cras mattis iudicium purus sit a diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentummet fermentum.
      </p>
      <h2 class="text-center">5 $</h2>
      <button id="orderbtn">Add To Basket </button>
     </div>
   
    </div>
  </a>
  </div>
 

  <div class="col-md-3 m-5 containerCategory">
    <div class="d-flex justify-content-end flex-column">
      <img class="img-fluid custom-width mx-auto image-top-center" src="http://127.0.0.1:8000/user/main-img/Main_IMG.png" alt="">
     <div class="CustomTextCard">
      <h2 class="text-center">Title</h2>
      <p class="text-justify customP text-center text-truncate">
        Diem certam indicere. Cras mattis iudicium purus sit a diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentummet fermentum.
      </p>
            <h2 class="text-center">5 $</h2>
            <button id="orderbtn">Add To Basket </button>

     </div>
    </div>
    
  </div> <div class="col-md-3 m-5 containerCategory">
    <div class="d-flex justify-content-end flex-column">
      <img class="img-fluid custom-width mx-auto image-top-center" src="http://127.0.0.1:8000/user/main-img/Main_IMG.png" alt="">
     <div class="CustomTextCard">
      <h2 class="text-center">Title</h2>
      <p class="text-justify customP text-center text-truncate">
        Diem certam indicere. Cras mattis iudicium purus sit a diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentummet fermentum.
      </p>
     </div>
    </div>
    
  </div> <div class="col-md-3 m-5 containerCategory">
    <div class="d-flex justify-content-end flex-column">
      <img class="img-fluid custom-width mx-auto image-top-center" src="http://127.0.0.1:8000/user/main-img/Main_IMG.png" alt="">
     <div class="CustomTextCard">
      <h2 class="text-center">Title</h2>
      <p class="text-justify customP text-center text-truncate">
        Diem certam indicere. Cras mattis iudicium purus sit a diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentummet fermentum.
      </p>
     </div>
    </div>
    
  </div> <div class="col-md-3 m-5 containerCategory">
    <div class="d-flex justify-content-end flex-column">
      <img class="img-fluid custom-width mx-auto image-top-center" src="http://127.0.0.1:8000/user/main-img/Main_IMG.png" alt="">
     <div class="CustomTextCard">
      <h2 class="text-center">Title</h2>
      <p class="text-justify customP text-center text-truncate">
        Diem certam indicere. Cras mattis iudicium purus sit a diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentummet fermentum.
      </p>
     </div>
    </div>
    
  </div> <div class="col-md-3 m-5 containerCategory">
    <div class="d-flex justify-content-end flex-column">
      <img class="img-fluid custom-width mx-auto image-top-center" src="http://127.0.0.1:8000/user/main-img/Main_IMG.png" alt="">
     <div class="CustomTextCard">
      <h2 class="text-center">Title</h2>
      <p class="text-justify customP text-center text-truncate">
        Diem certam indicere. Cras mattis iudicium purus sit a diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentummet fermentum.
      </p>
     </div>
    </div>
    
  </div> <div class="col-md-3 m-5 containerCategory">
    <div class="d-flex justify-content-end flex-column">
      <img class="img-fluid custom-width mx-auto image-top-center" src="http://127.0.0.1:8000/user/main-img/Main_IMG.png" alt="">
     <div class="CustomTextCard">
      <h2 class="text-center">Title</h2>
      <p class="text-justify customP text-center text-truncate">
        Diem certam indicere. Cras mattis iudicium purus sit a diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentummet fermentum.
      </p>
     </div>
    </div>
    
  </div> <div class="col-md-3 m-5 containerCategory">
    <div class="d-flex justify-content-end flex-column">
      <img class="img-fluid custom-width mx-auto image-top-center" src="http://127.0.0.1:8000/user/main-img/Main_IMG.png" alt="">
     <div class="CustomTextCard">
      <h2 class="text-center">Title</h2>
      <p class="text-justify customP text-center text-truncate">
        Diem certam indicere. Cras mattis iudicium purus sit a diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentummet fermentum.
      </p>
     </div>
    </div>
    
  </div> <div class="col-md-3 m-5 containerCategory">
    <div class="d-flex justify-content-end flex-column">
      <img class="img-fluid custom-width mx-auto image-top-center" src="http://127.0.0.1:8000/user/main-img/Main_IMG.png" alt="">
     <div class="CustomTextCard">
      <h2 class="text-center">Title</h2>
      <p class="text-justify customP text-center text-truncate">
        Diem certam indicere. Cras mattis iudicium purus sit a diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentummet fermentum.
      </p>
     </div>
    </div>
    
  </div> <div class="col-md-3 m-5 containerCategory">
    <div class="d-flex justify-content-end flex-column">
      <img class="img-fluid custom-width mx-auto image-top-center" src="http://127.0.0.1:8000/user/main-img/Main_IMG.png" alt="">
     <div class="CustomTextCard">
      <h2 class="text-center">Title</h2>
      <p class="text-justify customP text-center text-truncate">
        Diem certam indicere. Cras mattis iudicium purus sit a diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentummet fermentum.
      </p>
     </div>
    </div>
    
  </div> <div class="col-md-3 m-5 containerCategory">
    <div class="d-flex justify-content-end flex-column">
      <img class="img-fluid custom-width mx-auto image-top-center" src="http://127.0.0.1:8000/user/main-img/Main_IMG.png" alt="">
     <div class="CustomTextCard">
      <h2 class="text-center">Title</h2>
      <p class="text-justify customP text-center text-truncate">
        Diem certam indicere. Cras mattis iudicium purus sit a diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentummet fermentum.
      </p>
     </div>
    </div>
    
  </div> <div class="col-md-3 m-5 containerCategory">
    <div class="d-flex justify-content-end flex-column">
      <img class="img-fluid custom-width mx-auto image-top-center" src="http://127.0.0.1:8000/user/main-img/Main_IMG.png" alt="">
     <div class="CustomTextCard">
      <h2 class="text-center">Title</h2>
      <p class="text-justify customP text-center text-truncate">
        Diem certam indicere. Cras mattis iudicium purus sit a diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentummet fermentum.
      </p>
     </div>
    </div>
    
  </div> <div class="col-md-3 m-5 containerCategory">
    <div class="d-flex justify-content-end flex-column">
      <img class="img-fluid custom-width mx-auto image-top-center" src="http://127.0.0.1:8000/user/main-img/Main_IMG.png" alt="">
     <div class="CustomTextCard">
      <h2 class="text-center">Title</h2>
      <p class="text-justify customP text-center text-truncate">
        Diem certam indicere. Cras mattis iudicium purus sit a diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentummet fermentum.
      </p>
     </div>
    </div>
    
  </div> <div class="col-md-3 m-5 containerCategory">
    <div class="d-flex justify-content-end flex-column">
      <img class="img-fluid custom-width mx-auto image-top-center" src="http://127.0.0.1:8000/user/main-img/Main_IMG.png" alt="">
     <div class="CustomTextCard">
      <h2 class="text-center">Title</h2>
      <p class="text-justify customP text-center text-truncate">
        Diem certam indicere. Cras mattis iudicium purus sit a diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentummet fermentum.
      </p>
     </div>
    </div>
    
  </div> <div class="col-md-3 m-5 containerCategory">
    <div class="d-flex justify-content-end flex-column">
      <img class="img-fluid custom-width mx-auto image-top-center" src="http://127.0.0.1:8000/user/main-img/Main_IMG.png" alt="">
     <div class="CustomTextCard">
      <h2 class="text-center">Title</h2>
      <p class="text-justify customP text-center text-truncate">
        Diem certam indicere. Cras mattis iudicium purus sit a diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentummet fermentum.
      </p>
     </div>
    </div>
    
  </div> <div class="col-md-3 m-5 containerCategory">
    <div class="d-flex justify-content-end flex-column">
      <img class="img-fluid custom-width mx-auto image-top-center" src="http://127.0.0.1:8000/user/main-img/Main_IMG.png" alt="">
     <div class="CustomTextCard">
      <h2 class="text-center">Title</h2>
      <p class="text-justify customP text-center text-truncate">
        Diem certam indicere. Cras mattis iudicium purus sit a diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentummet fermentum.
      </p>
     </div>
    </div>
    
  </div> <div class="col-md-3 m-5 containerCategory">
    <div class="d-flex justify-content-end flex-column">
      <img class="img-fluid custom-width mx-auto image-top-center" src="http://127.0.0.1:8000/user/main-img/Main_IMG.png" alt="">
     <div class="CustomTextCard">
      <h2 class="text-center">Title</h2>
      <p class="text-justify customP text-center text-truncate">
        Diem certam indicere. Cras mattis iudicium purus sit a diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentummet fermentum.
      </p>
     </div>
    </div>
    
  </div> <div class="col-md-3 m-5 containerCategory">
    <div class="d-flex justify-content-end flex-column">
      <img class="img-fluid custom-width mx-auto image-top-center" src="http://127.0.0.1:8000/user/main-img/Main_IMG.png" alt="">
     <div class="CustomTextCard">
      <h2 class="text-center">Title</h2>
      <p class="text-justify customP text-center text-truncate">
        Diem certam indicere. Cras mattis iudicium purus sit a diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentummet fermentum.
      </p>
     </div>
    </div>
    
  </div> <div class="col-md-3 m-5 containerCategory">
    <div class="d-flex justify-content-end flex-column">
      <img class="img-fluid custom-width mx-auto image-top-center" src="http://127.0.0.1:8000/user/main-img/Main_IMG.png" alt="">
     <div class="CustomTextCard">
      <h2 class="text-center">Title</h2>
      <p class="text-justify customP text-center text-truncate">
        Diem certam indicere. Cras mattis iudicium purus sit a diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentummet fermentum.
      </p>
     </div>
    </div>
    
  </div> <div class="col-md-3 m-5 containerCategory">
    <div class="d-flex justify-content-end flex-column">
      <img class="img-fluid custom-width mx-auto image-top-center" src="http://127.0.0.1:8000/user/main-img/Main_IMG.png" alt="">
     <div class="CustomTextCard">
      <h2 class="text-center">Title</h2>
      <p class="text-justify customP text-center text-truncate">
        Diem certam indicere. Cras mattis iudicium purus sit a diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentummet fermentum.
      </p>
     </div>
    </div>
    
  </div> <div class="col-md-3 m-5 containerCategory">
    <div class="d-flex justify-content-end flex-column">
      <img class="img-fluid custom-width mx-auto image-top-center" src="http://127.0.0.1:8000/user/main-img/Main_IMG.png" alt="">
     <div class="CustomTextCard">
      <h2 class="text-center">Title</h2>
      <p class="text-justify customP text-center text-truncate">
        Diem certam indicere. Cras mattis iudicium purus sit a diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentummet fermentum.
      </p>
     </div>
    </div>
    
  </div> <div class="col-md-3 m-5 containerCategory">
    <div class="d-flex justify-content-end flex-column">
      <img class="img-fluid custom-width mx-auto image-top-center" src="http://127.0.0.1:8000/user/main-img/Main_IMG.png" alt="">
     <div class="CustomTextCard">
      <h2 class="text-center">Title</h2>
      <p class="text-justify customP text-center text-truncate">
        Diem certam indicere. Cras mattis iudicium purus sit a diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentummet fermentum.
      </p>
     </div>
    </div>
    
  </div> <div class="col-md-3 m-5 containerCategory">
    <div class="d-flex justify-content-end flex-column">
      <img class="img-fluid custom-width mx-auto image-top-center" src="http://127.0.0.1:8000/user/main-img/Main_IMG.png" alt="">
     <div class="CustomTextCard">
      <h2 class="text-center">Title</h2>
      <p class="text-justify customP text-center text-truncate">
        Diem certam indicere. Cras mattis iudicium purus sit a diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentummet fermentum.
      </p>
     </div>
    </div>
    
  </div> <div class="col-md-3 m-5 containerCategory">
    <div class="d-flex justify-content-end flex-column">
      <img class="img-fluid custom-width mx-auto image-top-center" src="http://127.0.0.1:8000/user/main-img/Main_IMG.png" alt="">
     <div class="CustomTextCard">
      <h2 class="text-center">Title</h2>
      <p class="text-justify customP text-center text-truncate">
        Diem certam indicere. Cras mattis iudicium purus sit a diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentummet fermentum.
      </p>
     </div>
    </div>
    
  </div> <div class="col-md-3 m-5 containerCategory">
    <div class="d-flex justify-content-end flex-column">
      <img class="img-fluid custom-width mx-auto image-top-center" src="http://127.0.0.1:8000/user/main-img/Main_IMG.png" alt="">
     <div class="CustomTextCard">
      <h2 class="text-center">Title</h2>
      <p class="text-justify customP text-center text-truncate">
        Diem certam indicere. Cras mattis iudicium purus sit a diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentum diem certam indicere. Cras mattis iudicium purus sit amet fermentummet fermentum.
      </p>
     </div>
    </div>
    
  </div>
  </div>
  

  </div>
@endsection